<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile RiskAssessment
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:RiskAssessment</sch:title>
    <sch:rule context="f:RiskAssessment">
      <sch:assert test="count(f:method) &gt;= 1">method: minimum cardinality of 'method' is 1</sch:assert>
      <sch:assert test="count(f:basis) &gt;= 1">basis: minimum cardinality of 'basis' is 1</sch:assert>
      <sch:assert test="count(f:prediction) &gt;= 1">prediction: minimum cardinality of 'prediction' is 1</sch:assert>
      <sch:assert test="count(f:prediction) &lt;= 1">prediction: maximum cardinality of 'prediction' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:RiskAssessment/f:method</sch:title>
    <sch:rule context="f:RiskAssessment/f:method">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:text) &gt;= 1">text: minimum cardinality of 'text' is 1</sch:assert>
      <sch:assert test="count(f:text) &lt;= 1">text: maximum cardinality of 'text' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:RiskAssessment/f:prediction</sch:title>
    <sch:rule context="f:RiskAssessment/f:prediction">
      <sch:assert test="count(f:extension[@url = 'https://fhir.heartlandprotocol.org/StructureDefinition/heartland-risk-score-total']) &lt;= 1">extension with URL = 'https://fhir.heartlandprotocol.org/StructureDefinition/heartland-risk-score-total': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:probability[x]) &lt;= 0">probability[x]: maximum cardinality of 'probability[x]' is 0</sch:assert>
      <sch:assert test="count(f:qualitativeRisk) &gt;= 1">qualitativeRisk: minimum cardinality of 'qualitativeRisk' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
